//
//  food.swift
//  ZYY-demo2
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 ZYY.4.17.SE.SCUT. All rights reserved.
//

import Foundation
class food {
    var name: String?
    var description: String?
    
    init(name:String?, description:String?){
        self.name = name
        self.description = description
        
    }
}
