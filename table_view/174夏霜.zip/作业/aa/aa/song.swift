//
//  song.swift
//  aa
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class song {
    var songName: String?
    var singerName: String?
    init(songName: String?, singerName: String?){
        self.songName = songName
        self.singerName = singerName
        
    }
}
