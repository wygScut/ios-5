//
//  singerNameViewController.swift
//  aa
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class singerNameViewController: UIViewController {
    
    @IBOutlet weak var songNameText: UITextField!
    @IBOutlet weak var singerNameText: UITextField!
    
    var songForEdit: song?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.songNameText.text = songForEdit?.songName
        self.singerNameText.text = songForEdit?.singerName
        self.navigationItem.title = songForEdit?.songName
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "saveToList" {
            print("save")
            songForEdit = song(songName: self.songNameText.text!,singerName: self.singerNameText.text!)
        }
        if segue.identifier == "cancelToList" {
            print("cancel")
        }
    }
    

}
