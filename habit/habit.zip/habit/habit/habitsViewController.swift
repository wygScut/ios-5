//
//  habitsViewController.swift
//  habit
//
//  Created by 魏一戈 on 2019/12/16.
//  Copyright © 2019 ZYY.4.17.SE.SCUT. All rights reserved.
//

import UIKit

class habitsViewController: UIViewController
{
    //var habit_alive=[Habit]()
    //let test=["1","2","3","4","5","6"]
    
    //let simpleTableIdentifier = "SimpleTableIdentifier"

   
    //这个是管理所有习惯的地方
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        add_habit(add_name: "吃饭", add_reminder: "饿了要吃饭", add_time_class: TimeClass.AFTERNOON)
         add_habit(add_name: "睡觉", add_reminder: "困了要睡觉", add_time_class: TimeClass.AFTERNOON)
        add_habit(add_name: "学习", add_reminder: "每天都要", add_time_class: TimeClass.AFTERNOON)
        
        
        for it in habits{
            if(it.alive!){
                habit_alive.append(it)
            }
        }
  */
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
