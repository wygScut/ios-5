//
//  allhabitsTableViewController.swift
//  habit
//
//  Created by 魏一戈 on 2019/12/16.
//  Copyright © 2019 ZYY.4.17.SE.SCUT. All rights reserved.
//

import UIKit

class allhabitsTableViewController:habitsViewController,UITableViewDataSource,UITableViewDelegate
{
    private var habitsCellID = "habitsCell"
    
    var habitsList: [Habit] = [Habit]()
    let defaultImg = UIImage (named:"myHabit")
    func initHabitsList(){
        habitsList.append(Habit(name: "吃饭", img: UIImage (named:"myHabit"), reminder:"饿了要吃饭"))
         habitsList.append(Habit(name: "睡觉", img: UIImage (named:"myHabit"), reminder:"困了要睡觉"))
        
    }
    
    
    @IBOutlet weak var allhabitsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initHabitsList()
        allhabitsTableView.delegate = self
        allhabitsTableView.dataSource = self
        self.allhabitsTableView.rowHeight = 100
    }
    
    
    // MARK: - Table view data source
    
     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return habitsList.count
    }
    
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: habitsCellID, for: indexPath)
        
        if let allHabitsTableCell = cell as? allhabitsTableViewCell {
        
            allHabitsTableCell.imageOfHabit.image =
                habitsList[indexPath.row].habitAvator
            allHabitsTableCell.NameOfHabit.text=habitsList[indexPath.row].name
            allHabitsTableCell.FlagOfHabit.text=habitsList[indexPath.row].reminder
            
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            //选中对应的cell

    }
   
    
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
