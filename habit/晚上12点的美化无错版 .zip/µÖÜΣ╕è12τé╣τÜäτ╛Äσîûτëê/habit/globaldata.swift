//
//  globaldata.swift
//  habit
//
//  Created by 魏一戈 on 2019/12/16.
//  Copyright © 2019 ZYY.4.17.SE.SCUT. All rights reserved.
//

import Foundation
var habitsList = [Habit]()
var habitsListToday = [Habit]()


//这个变量记录了上一次写入数据的时间
var lastUpdate=Date(timeIntervalSince1970: 0)
//var lastUpdate = Date(timeIntervalSince1970: 0)

//这里比较上一次更新的时间，来确定habitsListToday 需不需要更新
func should_init()->Bool
{
    let now = Date()
    let d_year = DateFormatter()
    let d_month = DateFormatter()
    let d_day = DateFormatter()
    d_year.dateFormat="yyyy"
    d_month.dateFormat="MM"
    d_day.dateFormat="dd"
    
    let n_year=d_year.string(from: now)
    
    let n_month=d_month.string(from: now)
    
    let n_day=d_day.string(from: now)
    
    let l_year=d_year.string(from: lastUpdate)
    
    let l_month=d_month.string(from: lastUpdate)
    
    let l_day=d_day.string(from: lastUpdate)
    
    if(l_year==n_year&&l_month==n_month&&l_day==n_day){
        return false
    }
    return true
}
