//
//  MoreSettingTableControllerViewController.swift
//  habit
//
//  Created by Apple on 2019/11/19.
//  Copyright © 2019 ZYY.4.17.SE.SCUT. All rights reserved.
//

import UIKit

extension UIImage{
    func resizeImg(reSize:CGSize)->UIImage{
        UIGraphicsBeginImageContextWithOptions(reSize, false, UIScreen.main.scale)
        self.draw(in:CGRect(x: 0.0,y: 0.0,width: reSize.width,height: reSize.height))
        let reSizeImage:UIImage = (UIGraphicsGetImageFromCurrentImageContext()!)
        return reSizeImage
    }
    //scale down at the same proportion
//    func scaleImage(scaleSize:CGFloat)->UIImage{
//        let resize = CGSizeMake(self.size.width * scaleSize, self.size.height * scaleSize)
//        return resizeImg(reSize: resize)
//    }
}

class MoreSettingTableViewController: MoreViewController, UITableViewDelegate, UITableViewDataSource {
    
    private var CELL_IDENTIFIER = "OptionsCell"
    
    var optionsList: [options] = [options]()
    let defaultImg = UIImage(named:"myHabit")
    func initOptionsList() {
        optionsList.append(options(name: "myHabits", img: UIImage(named:"myHabit")))
        optionsList.append(options(name: "myCards", img: UIImage(named: "cards")))
        optionsList.append(options(name: "Finished", img: UIImage(named: "finished")))
        optionsList.append(options(name: "settings", img: UIImage(named: "setting")))
        optionsList.append(options(name: "contact us", img: UIImage(named: "about")))
    }
    
    @IBOutlet weak var settingTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initOptionsList()
        settingTableView.delegate = self
        settingTableView.dataSource = self
    }
    
    // MARK: - Table view data source
    
     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return optionsList.count
    }
    
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER, for: indexPath)
        
        if let optionCell = cell as? optionsTableViewCell {
            
            optionCell.imageOfOptions.image = optionsList[indexPath.row].optionsAvator
            optionCell.NameOfOptions.text = optionsList[indexPath.row].optionsName
//            let reSize = CGSize(width: 60.0, height: 60.0)
//            optionCell.imageOfOptions.image = resizeImg(reSize: reSize)
            // Configure the cell...
        }
        
        return cell
    }
    
    
    
    // Override to support editing the table view.
     func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
}
