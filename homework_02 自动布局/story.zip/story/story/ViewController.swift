//
//  ViewController.swift
//  story
//
//  Created by Apple on 2019/9/17.
//  Copyright © 2019 Jacqueline. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var phone: UIStackView!
    @IBOutlet var home: UIStackView!
    @IBOutlet var work: UIStackView!
    @IBOutlet var mail: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func deleteContacts(_ sender: Any) {
    }
    
    @IBAction func share(_ sender: Any) {
    }
    
    @IBAction func stop(_ sender: Any) {
    }
    
    
}

