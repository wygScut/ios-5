//
//  descriptionViewController.swift
//  homework4
//
//  Created by Apple on 2019/10/29.
//  Copyright © 2019 Jacqueline. All rights reserved.
//

import UIKit

class descriptionViewController: UIViewController {
    
    @IBOutlet var nameText: UITextField!
    @IBOutlet var descriptionText: UITextField!
    
    
    @IBOutlet var cancelButtion: UIButton!
    @IBOutlet var saveButton: UIButton!
    
    var foodForEdit: food?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.nameText.text = foodForEdit?.name
        self.descriptionText.text = foodForEdit?.foodDescription
        self.navigationItem.title = foodForEdit?.name
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        foodForEdit = food(name: nameText.text, foodDescription: descriptionText.text)
    }
    
    
}
