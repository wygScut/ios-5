//
//  food.swift
//  homework4
//
//  Created by Apple on 2019/10/29.
//  Copyright © 2019 Jacqueline. All rights reserved.
//

import Foundation
class food: NSObject, NSCoding{
    func encode(with aCoder: NSCoder){
        aCoder.encode(name, forKey: "nameKey")
        aCoder.encode(foodDescription, forKey: "descriptionKey")
    }
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "nameKey") as? String
        foodDescription = aDecoder.decodeObject(forKey: "descriptionKey") as? String
    }
    var name: String?
    var foodDescription: String?
    static let DocumentDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentDirectory.appendingPathComponent("foodList")
    init(name: String?, foodDescription: String?) {
        self.name = name
        self.foodDescription = foodDescription
        
    }
}
