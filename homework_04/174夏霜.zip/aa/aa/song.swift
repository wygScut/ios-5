//
//  song.swift
//  aa
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class song: NSObject, NSCoding {
    
    func encode(with aCoder: NSCoder){
        aCoder.encode(songName, forKey: "songnameKey")
        aCoder.encode(singerName, forKey: "singernameKey")
        aCoder.encode(songCategory, forKey: "songcategoryKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        songName = aDecoder.decodeObject(forKey: "songnameKey") as? String
        singerName = aDecoder.decodeObject(forKey: "singernameKey") as? String
        songCategory = aDecoder.decodeObject(forKey: "songcategoryKey") as? String
    }
    
    var songName: String?
    var singerName: String?
    var songCategory: String?
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("songList")
    
    init(songName: String?, singerName: String?, songCategory: String?){
        self.songName = songName
        self.singerName = singerName
        self.songCategory = songCategory
    }
}
