//
//  ViewController.swift
//  outlet
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 Jacqueline. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var myTitleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   
    @IBOutlet var account: UITextField!
    @IBOutlet var password: UITextField!
    
    @IBAction func setTitleLabel(_ sender: Any) {
        if (account.text == "a" && password.text == "abc"){
        myTitleLabel.text = "登录成功"
        }
        else{
            myTitleLabel.text = "该用户不存在"
        }
    }
    
}

