//
//  globaldata.swift
//  habit
//
//  Created by 魏一戈 on 2019/12/16.
//  Copyright © 2019 ZYY.4.17.SE.SCUT. All rights reserved.
//

import Foundation
var habitsList = [Habit]()
var habitsListToday = [Habit]()


//这个变量记录了上一次写入数据的时间
var lastUpDate=lastUpDateClass()
