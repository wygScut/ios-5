import UIKit

var scords :[String] = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
var types : [String] = ["spade","hearts","blossom","diamond"]
class Card{
    var type: String
    var scord: String
    init(type: String,scord: String){
        self.scord = scord
        self.type = type
    }
    func show(){
    print("这张牌是 "+self.type+" "+self.scord)
    }
    
}

class op{
    var Cards=[Card]()
    init(){
        //这里初始化数组
        for i in 0...3{
        for j in 0...12{
            let temp=Card(type:types[i], scord:scords[j])
            Cards.append(temp)
            //temp.show();
        }
        }
        var i=51;
        while i>=0{
//            swp(Cards[i],Cards[rand()%(i+1)]);
            let temp = Cards[i]
            let tag = Int(arc4random())%(i+1)
            Cards[i]=Cards[tag]
            Cards[tag]=temp
            //Cards[i].show()
            i=i-1
        }
        
        
    }
    
    func licensing(nums_of_people:Int,cards_of_each_person:Int){
        let total=nums_of_people*cards_of_each_person;
        if(total>52){
            print("要发的牌太多啦！")
        }
            else{
            var i=0;
            var tag=0
            while i<nums_of_people {
                var j=0
                print(i+1)
                while j<cards_of_each_person {
                    
                    Cards[tag].show()
                    
                    tag+=1
                    j+=1
                }
                i+=1
            }
        }
        
    }
    
}

//这里初始化了牌组
var a=op();
a.licensing(nums_of_people: 3, cards_of_each_person: 3)
